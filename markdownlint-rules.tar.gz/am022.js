// @ts-check

"use strict";

const shared = require("./shared");

module.exports = {
  "names": [ "AM022", "header-anchor-collision" ],
  "description": "Heading anchor has collision",
  "tags": [ "headings", "headers" ],
  "function": function AM022(params, onError) {
    var anchors = new Map()
    var checkGeneratedAnchors = false
    var casesensitive = false
    const anchorMissingHashRe = new RegExp("{[^#].*}$");
  
    /* loop one to get list of all anchors */
    shared.forEachHeading(params, function forHeading(heading, content) {
      var headingline = heading.line.replace(/^[#]+ /, '').replace(/[\s]*\{\#.*?\}[\s]*$/, '')
      var anchorid = heading.line.replace(/^.*?[\s]*\{\#(.*?)\}[\s]*$/, '\$1')
      if (casesensitive) {
        anchorid = anchorid.toLowerCase()
      }
      if (anchorid.startsWith("#")) {  // no anchor id, bare heading
        anchorid = ""
      }
      var sluganchorid = ''
      headingline = headingline.replace(/\[!DNL (.*?)]/, "\$1")
      headingline = headingline.replace(/\[!UICONTROL (.*?)]/, "\$1")
      if (heading.line.search(/\{#.*?\}$/) < 0) {
        sluganchorid = shared.slugify(headingline)
        if (casesensitive) {
          sluganchorid = sluganchorid.toLowerCase()
        }
      }
      var key = ''
      key = anchorid
      var linenumber = heading.lineNumber
      var instance = { anchorid: anchorid, slug: sluganchorid, linenumber: heading.lineNumber /*+ params.frontMatterLines.length*/}
      if (anchorid == '') {
          key = sluganchorid
      }
      key = key.toString()
      if (!(anchors.has(key))) {
        anchors.set(key, [])
      } 
      if (anchorid != '' || checkGeneratedAnchors) {
        var ilist = anchors.get(key)
        ilist.push(instance)
        anchors.set(key, ilist)
      }
    });
    anchors.forEach(function check(value, key, map) {
      if (value.length > 1) {
        for (const [ikey, instance] of Object.entries(value)) {
          if (instance.anchorid == '' && checkGeneratedAnchors) { //collision with slugified
            shared.addError(onError, instance.linenumber, null, "Generated anchor from heading is duplicate '" + key + "'")
          } else {
            shared.addError(onError, instance.linenumber, null, "Duplicate anchor '" + key + "'")
          }
        }
      }
  })
    // for (const [key, value] of Object.entries(anchors)) {
    //   if (value.length > 1) {
    //     for (const [ikey, instance] of Object.entries(value)) {
    //       if (instance.anchorid == '') { //collision with slugified
    //         // shared.addError(onError, instance.linenumber, null, "Generated anchor from heading is duplicate '" + key + "'")
    //         // turning off because I believe clue has collision avoidance for anchors
    //       } else {
    //         shared.addError(onError, instance.linenumber, null, "Duplicate anchor '" + key + "'")
    //       }
    //     }
    //   }
    // }
  }
};
