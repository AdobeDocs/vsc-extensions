// @ts-check

"use strict";

const shared = require("./shared");

module.exports = {
  "names": [ "AM022", "header-anchor-collision" ],
  "description": "Heading anchor has collision",
  "tags": [ "headings", "headers" ],
  "function": function AM022(params, onError) {
    var anchors = []
    const anchorMissingHashRe = new RegExp("{[^#].*}$");
  
    /* loop one to get list of all anchors */
    shared.forEachHeading(params, function forHeading(heading, content) {
      var headingline = heading.line.replace(/^[#]+ /, '').replace(/ \{\#.*?\}[\s]*$/, '')
      var anchorid = heading.line.replace(/^.*? \{\#(.*?)\}[\s]*$/, '\$1')
      if (anchorid.startsWith("#")) {
        anchorid = ""
      }
      var sluganchorid = ''
      headingline = headingline.replace(/\[!DNL (.*?)]/, "\$1")
      headingline = headingline.replace(/\[!UICONTROL (.*?)]/, "\$1")
      if (heading.line.search(/\{#.*?\}$/) < 0) {
        sluganchorid = shared.slugify(headingline)
      }
      // console.log(sluganchorid)
      var instance = { anchorid: anchorid, slug: anchorid, linenumber: heading.lineNumber /*+ params.frontMatterLines.length*/}
      // for (var i = 0; i < anchors.length; i++) {
      //   if (anchors[i].anchorid == sluganchorid) {
      //     // console.log(anchors[i])
      //     shared.addError(onError, instance.linenumber, heading.line, "Duplicate anchor " + anchors[i].anchorid + " found on line " + (anchors[i].linenumber + params.frontMatterLines.length));
      //   }
      // }

      if (anchorid != '') {
        // console.log('A ' + anchorid + ': ' + headingline)
        anchors.push(instance)
      }
      // if (sluganchorid != '') {
      //   console.log('S ' + sluganchorid + ': ' + headingline)
      // }

      /* loop two for validation */
      shared.forEachHeading(params, function forHeading(heading, content) {
        var headingline = heading.line.replace(/^[#]+ /, '').replace(/ \{\#.*?\}$/, '')
        var anchorid = heading.line.replace(/^.*? \{\#(.*?)\}$/, '\$1')
        if (anchorid.startsWith("#")) {
          anchorid = ""
        }
        var sluganchorid = ''
        headingline = headingline.replace(/\[!DNL (.*?)]/, "\$1")
        headingline = headingline.replace(/\[!UICONTROL (.*?)]/, "\$1")
        if (heading.line.search(/\{#.*?\}$/) < 0) {
          sluganchorid = shared.slugify(headingline)
        }
        var instance = { anchorid: anchorid, slug: anchorid, linenumber: heading.lineNumber /*+ params.frontMatterLines.length*/}
        for (var i = 0; i < anchors.length; i++) {
          if (anchors[i].anchorid == sluganchorid || anchors[i].anchorid == anchorid) {  //} || anchors[i].anchorid == anchorid) {
            // console.log(heading.line)
            // console.log(anchorid, ':', anchors[i].anchorid, ':', sluganchorid, '\n')
            if (instance.linenumber != anchors[i].linenumber) {
              shared.addError(onError, instance.linenumber, heading.line, "Duplicate anchor " + anchors[i].anchorid + " found on line " + (anchors[i].linenumber + params.frontMatterLines.length));
            }
          }
        }
      });
    });
  }
};
